const express = require("express");
const { join } = require("path");
const app = express();
app.use(express.urlencoded({ extended: true })); 
app.set("view engine", "pug");
app.set("views", join(__dirname, "views"));

const morgan = require("morgan");
const {createWriteStream} = require("fs");
 
const logFile = join(__dirname, "blogchefNew.log");   
 
/*--------------Morgan module ------------------*/
app.use(morgan(":method - :url - :date - :response-time ms"));  
app.use(
  morgan(":method -:url - :date - :response-time ms", {
    stream: createWriteStream(logFile, { flags: "a" }),
  })
);
//---------------- end ------------------------//
 

// Serve static files if needed
app.use("/assets", express.static(join(__dirname, "public")));

app.get("/", (req, res) => {
  res.render("home");
});

app.get("/register", (req, res) => {
  res.render("register");
});

// Handle form submission from register page
app.post("/register", (req, res) => {
  // Just print form data to console for demo purposes
  console.log("Registration data:", req.body);

  // Normally, you'd save user data and maybe redirect to sign-in
  res.send("<h2>Registration successful!</h2><a href='/'>Go to Home</a>");
});

// Redirect cancel button to home page
app.post("/register/cancel", (req, res) => {
  res.redirect("/");
});

// Placeholder Sign In page
app.get("/signin", (req, res) => {
  res.send("<h2>Sign In Page (not implemented)</h2><a href='/'>Go to Home</a>");
});

const PORT = 3001;
app.listen(PORT, () => console.log(`Yatri.com running on port ${PORT}`));
