console.log("Task Start");
var obj = require('./task1');
var readLine = require('readline');  

var r1 = readLine.createInterface({
    input : process.stdin,
    output: process.stdout
});

r1.question('Enter Id: ', function(id) {
    r1.question('Enter Name: ', function(name) {
        r1.question('Enter Category: ', function(category) {
            r1.question('Enter Price: ', function(price) {
                r1.question('Enter Stock: ', function(stock) {
                    r1.question('Enter Rating: ', function(rating) {
                        
                        obj.product(id, name, category, price, stock, rating);

                        var dummy_data = obj.load();
                        obj.write(dummy_data);
                        obj.user1();
                        obj.user2();
                        obj.user3();
                        obj.delete();

                        console.log("Task Completed");

                        r1.close(); 

                    });
                });
            });
        });
    });
});
