const express =require('express')
const task = require('./task')
const app = express.Router()

app.use('/yatri/profile',task); //use routeExample.js to handle routes starting with '/'

module.exports = app;