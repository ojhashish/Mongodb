const express = require('express')
const router= express.Router()

router.route('/stud/:username/')  
    .get((req,res)=>{
        console.log(req.params.username); 
        if(req.params.username==='Daniel'){
        res.send(' welcome to page, ' + req.params.username)
        }
        else
        {
            res.status(400).send('Daniel Not Found')
        }
})

router.route('/prof/:username/')   
    .get((req,res)=>{
        console.log(req.params.username); 
        res.send(' welcome to page, ' + req.params.username )
})

router.route('/emp')   
    .get((req,res)=>{
        res.send(' Hey you are new here')
})

module.exports = router;